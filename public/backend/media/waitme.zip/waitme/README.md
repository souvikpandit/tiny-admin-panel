waitMe
======

jquery plugin for easy creating loading css3 animations<br>
Simple to use. Contains 14 animation effects and can use images.

<i>For work required only jQuery, other libraries are not required.</i>
<i>Plugin works on all browsers and IE10+ (for css3 animation effects).</i>
<br>

Documentation
=============

<a href="http://vadimsva.github.io/waitMe/" target="_blank"><b>DOCUMENTATION & EXAMPLES</b></a>


License
=======

The MIT License (MIT)
